package com.syswin.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TableUtil {

    public static Map<String,List<String>> doGet() {
        Connection conn = null;
        // 1、获取数据库所有表
        List<String> tables = new ArrayList<String>();
        Map<String,List<String>> tabs = new HashMap<String,List<String>>();
        List<String> tmp = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = java.sql.DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test?useUnicode=true&allowPublicKeyRetrieval=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2b8", "root", "admin");
            DatabaseMetaData dbMetaData = conn.getMetaData();
            ResultSet rs = dbMetaData.getTables(null, null, null,new String[] { "TABLE" });
            while (rs.next()) {// ///TABLE_TYPE/REMARKS
                /**
                 * 获取数据库表相关信息的方法
                 * rs.getString("TABLE_NAME"):表名
                 * rs.getString("TABLE_TYPE"):表类型
                 * rs.getString("TABLE_CAT"):表所属数据库
                 * rs.getString("TABLE_SCHEM"):表所属用户名
                 * rs.getString("REMARKS"):表备注
                 */
                String table_cat = rs.getString("TABLE_CAT");
                if("test".equals(table_cat)){
                    tables.add(rs.getString("TABLE_NAME"));
                }
            }

            // 2、遍历数据库表，获取各表的字段等信息
            for (String tableName : tables) {
                tmp = new ArrayList<>();
                String sql = "select * from " + tableName;
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ResultSet resultSet = ps.executeQuery();
                    ResultSetMetaData meta = resultSet.getMetaData();
                    int columeCount = meta.getColumnCount();
                    for (int i = 1; i < columeCount + 1; i++) {
                        /**
                         * 获取表字段信息
                         * meta.getColumnName(i):字段名
                         * meta.getColumnType(i):类型
                         */
                        tmp.add(meta.getColumnName(i));
                    }
                    tabs.put(tableName,tmp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return tabs;
    }

}
