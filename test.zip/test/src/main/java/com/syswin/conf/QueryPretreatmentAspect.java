package com.syswin.conf;

import com.syswin.dao.dto.CommonQuery;
import com.syswin.dao.dto.PersonQuery;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.servlet.http.HttpServletRequest;

@Aspect
@Configuration
public class QueryPretreatmentAspect {

    @Autowired
    private HttpServletRequest request;

    /**
     * 切面，拦截controller下common包及子包下所有方法
     */
    @Pointcut("execution(* com.syswin.web..*.*(..))")
    private void queryMicroPretreatmentPointcut() {

    }

    @Around(value = "queryMicroPretreatmentPointcut()")
    public Object queryMicroPretreatment(ProceedingJoinPoint point) throws Throwable {
        String path = request.getServletPath();
        Object[] args = point.getArgs();
//        CommonQuery commonQueries = null;
//        for(Object object : args){
//            commonQueries = (CommonQuery)object;
//        }
        return point.proceed(args);
    }

}
