package com.syswin.service;

import com.syswin.dao.bean.Person;

import java.util.List;

public interface PersonService {

    List<Person> getList();

    int save(Person person);

    Person getById(Long id);

    void updateTable(String age,String tableName,String type,Integer length);
}
