package com.syswin.service.impl;
import com.syswin.dao.PersonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TaskA implements Runnable{

    @Autowired
    private PersonMapper personMapper;

    @Override
    public void run() {
        int i = personMapper.delete();
        System.out.println("共清除无效数据"+i+"条");
    }
}
