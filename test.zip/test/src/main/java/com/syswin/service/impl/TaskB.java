package com.syswin.service.impl;
import com.syswin.dao.PersonMapper;
import com.syswin.dao.bean.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class TaskB implements Runnable{

    @Autowired
    private PersonMapper personMapper;

    @Override
    public void run() {
        Person person = new Person();
        person.setName("张"+ new Random().nextInt(100));
        person.setAge(new Random().nextInt(100));
        person.setEmail("em"+new Random().nextInt(100));
        person.setIsDelete(1);
        person.setPhone("tep"+new Random().nextInt(100));
        personMapper.save(person);
    }
}
