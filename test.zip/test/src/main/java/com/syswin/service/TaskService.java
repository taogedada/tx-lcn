package com.syswin.service;

public interface TaskService {

}
