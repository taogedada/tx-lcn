package com.syswin.service.impl;

import com.codingapi.txlcn.tc.annotation.LcnTransaction;
import com.codingapi.txlcn.tc.annotation.TxTransaction;
import com.syswin.dao.PersonMapper;
import com.syswin.dao.bean.Department;
import com.syswin.dao.bean.Person;
import com.syswin.fegin.DepartmentFegin;
import com.syswin.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonMapper personMapper;

    @Autowired
    private DepartmentFegin departmentFegin;

    @Override
    public List<Person> getList() {
        return personMapper.getList();
    }

    @Override
    @Transactional
    //参与方与发起方只要有一方不加@TxTransaction注解，则无法开启分布式事务，数据的一致性无法得到保证
    @TxTransaction
    public int save(Person person) {
        int i = 0;
            i = personMapper.save(person);
        Department department = new Department();
        department.setUserId(person.getId());
        department.setDepartName("测试");
        int j = departmentFegin.save(department);
        int r = i+j;
        System.out.println(r);
            if(i == 1){
                throw new RuntimeException("error");
            }
        return r;
    }

    @Override
    public Person getById(Long id) {
        return personMapper.getById(id);
    }

    @Override
    public void updateTable(String age,String tableName,String type,Integer length) {
        personMapper.updateTable(age,tableName,type,length);
    }
}
