package com.syswin.dao.bean;

import lombok.Data;

import java.util.List;

@Data
public class Person {
    private Long id;

    private String name;

    private String email;

    private String phone;

    private Integer age;

    private Integer isDelete;

}
