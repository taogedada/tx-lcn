package com.syswin.dao.bean;

import lombok.Data;

@Data
public class Task {

    private Integer cronId;

    private String cronKey;

    private String cronExpression;

    private String taskExplain;

    private Integer status;
}
