package com.syswin.dao;

import com.syswin.dao.bean.Task;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TaskMapper {

    List<Task> findAll();

    Task findByCronId(@Param("cronId") Integer cronId);
}
