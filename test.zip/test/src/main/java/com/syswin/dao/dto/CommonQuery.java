package com.syswin.dao.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CommonQuery {

    protected Integer id;

    protected String name;

}
