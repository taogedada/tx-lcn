package com.syswin.dao.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PersonQuery extends CommonQuery{

    private String department;

    private Integer age;
}
