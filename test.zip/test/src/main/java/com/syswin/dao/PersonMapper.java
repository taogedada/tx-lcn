package com.syswin.dao;

import com.syswin.dao.bean.Person;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PersonMapper {

    List<Person> getList();

    int save(@Param("person") Person person);

    Person getById(@Param("id")Long id);

    void updateTable(@Param("age")String age,@Param("tableName")String tableName,@Param("type")String type,@Param("length")Integer length);

    int delete();
}
