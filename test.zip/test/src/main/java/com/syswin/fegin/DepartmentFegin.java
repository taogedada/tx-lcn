package com.syswin.fegin;

import com.syswin.dao.bean.Department;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(value = "TestA")
public interface DepartmentFegin {

    @PostMapping("/save")
    public int save(@RequestBody Department department);
}
