package com.syswin.web;

import com.syswin.service.TaskService;
import com.syswin.service.impl.TaskA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Executor;

@RestController
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private TaskA taskA;

    @Autowired
    @Qualifier(value = "ddd")
    private Executor executor;

    @RequestMapping("doTask")
    public void doTask(){
        executor.execute(taskA);
    }
}
