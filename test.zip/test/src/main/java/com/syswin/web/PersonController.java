package com.syswin.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.syswin.dao.bean.Person;
import com.syswin.dao.dto.PersonQuery;
import com.syswin.service.PersonService;
import com.syswin.util.TableUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
public class PersonController {

    @Autowired
    private PersonService personService;

    @GetMapping("/getList")
    public List<Person> getList(){
        List<Person> ps = new ArrayList<>();
        for(int j = 0;j<3;j++){
            Person p = new Person();
            inits(p,ps);
        }

        return personService.getList();
    }

    public void inits(Person p,List<Person> ps){
        ps.add(p);
    }

    @PostMapping("/getById")
    public Person getById(@RequestBody PersonQuery personQuery){
        Person person = new Person();
        return person;
    }

    @PostMapping("/save")
    public int save(@RequestBody Person person){
        int i = personService.save(person);
        return i;
    }

    @GetMapping("/getTables")
    public Map<String,List<String>> getTables(){
        return TableUtil.doGet();
    }

    @GetMapping("/updateTable")
    public void updateTable(@RequestParam("column")String column,@RequestParam("tableName")String tableName,@RequestParam("type")String type,@RequestParam("length")Integer length){
        personService.updateTable(column,tableName,type,length);
    }



}
