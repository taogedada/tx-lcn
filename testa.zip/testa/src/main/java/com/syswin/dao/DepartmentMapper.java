package com.syswin.dao;

import com.syswin.dao.bean.Department;
import org.apache.ibatis.annotations.Param;

public interface DepartmentMapper {

    int save(@Param("department") Department department);
}
