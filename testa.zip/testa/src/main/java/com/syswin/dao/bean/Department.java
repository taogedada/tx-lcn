package com.syswin.dao.bean;

import lombok.Data;

@Data
public class Department {

    private Long id;

    private Long userId;

    private String departName;

}
