package com.syswin.service;

import com.syswin.dao.bean.Department;

public interface DepartmentService {

    int save(Department department);
}
