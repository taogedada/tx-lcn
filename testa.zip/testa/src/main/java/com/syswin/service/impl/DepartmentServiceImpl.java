package com.syswin.service.impl;

import com.codingapi.txlcn.tc.annotation.LcnTransaction;
import com.codingapi.txlcn.tc.annotation.TxTransaction;
import com.syswin.dao.DepartmentMapper;
import com.syswin.dao.bean.Department;
import com.syswin.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentMapper departmentMapper;

    @Override
    @Transactional
    @TxTransaction
    public int save(Department department) {
        int i = departmentMapper.save(department);
//        if(i == 1){
//            throw new RuntimeException("error");
//        }
        return i;
    }
}
