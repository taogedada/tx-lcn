package com.syswin.controller;

import com.syswin.dao.bean.Department;
import com.syswin.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping("/save")
    public int save(@RequestBody Department department){
        int i = departmentService.save(department);
        System.out.println(department.getId());
        return i;
    }

}
